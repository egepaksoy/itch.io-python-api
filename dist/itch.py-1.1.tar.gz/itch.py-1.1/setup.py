from setuptools import setup, find_packages

setup(
    name = "itch.py",
    version = "1.1",
    author = "Ege Paksoy",
    author_email = "egepaskoy@gmail.com",
    packages = find_packages(),
    license_files = ('LICENSE.txt')
)